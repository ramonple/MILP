# End-to-end motor insurance retention MIP — practical template

## What this includes

`end_to_end_retention.py` runs these stages:
1. Synthetic *randomised* historical offer pilot with renewal outcomes and observed claims for renewed accounts.
2. Train/holdout evaluation of (a) offer-conditioned renewal probability (logistic regression with offer interactions) and (b) claims cost conditional on renewal (ridge regression).
3. Generate 0%, 5%, and 10% offer scenarios for 800 new customers.
4. Estimate scenario-level net expected underwriting contribution, expected redeemed discount spend, and claims exposure.
5. Binary MILP offer selection: exactly one offer per customer, expected discount/contact budget, outreach capacity, eligibility, and expected-claim-exposure guardrail.
6. Verify solution and export customer instructions, scored candidate scenarios and baseline comparison.

## Install and run

For PuLP 4.x, use Python 3.12+ and a CBC installation:

```bash
python -m pip install numpy pandas scikit-learn 'pulp[cbc]'
python end_to_end_retention.py
```

The script also attempts to support PuLP 3.x's variable and CBC APIs. In 3.x, ensure CBC is installed and discoverable. It has **not** been runtime-tested in this environment with PuLP because PuLP/CBC are not installed here; the script was syntax-checked and the data generation, model fitting and scoring components were exercised.

## Outputs

- `outputs/scored_customer_offer_scenarios.csv`: a row per customer and candidate offer, with probabilities, financial estimates and eligibility flags.
- `outputs/optimised_customer_offers.csv`: one offer per customer, with expected profit and spend.
- `outputs/strategy_comparison.csv`: model-estimated KPI comparison versus 0% discount for all customers.

## How to replace synthetic data with real data

Replace `simulate_pilot` with historically observed policies including *pre-offer* covariates, the assigned offer, renewal outcome and (where available) claim costs. Replace `build_customers` with the current renewal pipeline. Ensure there are no post-offer or future-outcome feature leaks. Retrain on an appropriate temporal split and verify randomisation or causal identification for offer effects. Account for exposure windows and claims development (the synthetic example has an intentionally simplified single-period target).

Replace illustrative `offer_eligibility` with *approved* eligibility and pricing checks; add legal, regulatory, conduct, customer outcomes, exclusions, and operational constraints, including FCA general insurance pricing rules where applicable.

## Critical business interpretation

`expected_profit = P(renew | offer) * (discounted premium - E[claims | renew] - servicing cost) - contact cost`.

`budget_cost = P(renew | offer) * premium * discount_rate + contact cost`.

The discount appears in the discounted premium inside net expected profit and in the **separate budget constraint**. Do **not** subtract the discount twice from profit.

The risk constraint in this example compares expected selected-policy claims exposure with the no-offer portfolio's expected claims exposure. This is **not** a statutory solvency-capital calculation and is only a classroom risk guardrail.

The reported uplift is model-based, not proven real-world incremental profit. Real applications require causal offer-response estimation, offline policy validation, an experimental or otherwise defensible impact evaluation, calibration, uncertainty/sensitivity analysis, conduct review, and post-deployment monitoring. In particular, nominal MIP optimality is conditional on estimated input values.

## Ideas for an advanced extension

- Replace logistic response modelling with uplift/causal estimators and propensity methods.
- Add confidence bounds or scenario-based robust optimisation for model uncertainty.
- Calibrate claims cost by product, geographic exposure and development period.
- Add concentration limits, treatment eligibility, fairness monitoring and channel-specific contact constraints.
- Backtest decisions on a holdout experiment, and test a production challenger with appropriate safeguards.
